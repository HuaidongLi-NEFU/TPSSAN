about the LA dataset,set the dataset following format
data
--LA
----2018LA_Seg_Training Set
------XXXXXXXXX(like this  "06SR5RBREL16DQ6M8LWS")
--------mri_norm2.h5



about the CETUS dataset,set the dataset following format

data
--CETUS
----CETUS
------patientXX.h5,  (like this  "image0001_norm.h5")

