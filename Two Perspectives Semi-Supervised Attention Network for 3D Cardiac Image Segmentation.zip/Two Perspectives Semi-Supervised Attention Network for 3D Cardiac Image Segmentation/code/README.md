Running the Training
1.Clone the repository
2.Put the data
3.Train the mode


